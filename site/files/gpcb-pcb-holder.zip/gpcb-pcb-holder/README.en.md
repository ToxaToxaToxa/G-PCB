# PCB blank holder for the CNC 3018

A 3D-printed holder for copper-clad blanks on a CNC 3018 with M5 T-slots. A fixed corner stop gives a repeatable X0 Y0: the blank always goes into the same corner, so the work zero can be found again after the machine was switched off. Two sliding fences hold blanks of any size.

**Check before printing:** the T-slot dimensions come from a model of the machine (slot pitch 30 mm, opening 6 mm, neck depth 4 mm), not from a measurement. Compare them with your bed.

## Files

| Path | What it is |
|---|---|
| `print/corner-stop.stl` | Corner stop (L), defines X0 Y0 — 1 pc |
| `print/key-strip.stl` | Key strip: fits into the groove under the corner stop and into the T-slot, keeps the stop square to X — 1 pc |
| `print/x-fence.stl` | X fence: slides along the T-slot, pushes the blank from +X — 1 pc |
| `print/y-fence.stl` | Y fence: slides across the T-slots on two long slots, pushes the blank from +Y — 1 pc |
| `pcb-holder.step` | All holder parts with the spacer and the blank, for editing in any CAD |
| `holder-hardware.step` | M5 ISO 7380 screws and T-nuts in place |
| `renders/` | Renders of the assembled holder |

## Print

- PETG, 0.4 mm nozzle, 0.2 mm layers (0.16 mm is better for the 0.8 mm lips).
- Every part prints flat on its base, no supports; the 1.2 mm lip over the blank edge is a short overhang.
- 40–60 % infill, 3–4 perimeters.

## What to buy

| Item | Qty | Note |
|---|---|---|
| Screw M5 × 10, button head, hex socket, ISO 7380 | 7 + 3 spare | The Ø9.5 × 2.75 mm head sits fully in the Ø10 × 3 mm counterbore. 3 mm hex key |
| Screw M5 × 12, ISO 7380 | 7 | In case M5×10 does not reach far enough into your T-nuts |
| T-nut M5 for the bed slots | 7 | |
| PETG filament 1.75 mm | ≈ 70 g | The four parts are 54 cm³ |

No washers (they do not fit in the counterbore with a button head) and no heat-set inserts. The spacer is a piece of old 1.6 mm copper-clad of the blank size.

**Screw length:** 4 mm of plastic under the head + T-slot neck (4 mm in the model) + T-nut thickness. The thread must engage at least 3 mm, and the screw must not bottom out in the slot. Simplest check: screw an M5×10 into a T-nut in the slot without a part — tightened, it should stick out 4 mm above the bed and already hold the nut.

## Heights above the bed

| What | Height |
|---|---|
| Spacer (old copper-clad) | 0 … 1.6 mm |
| Blank, copper on top | 1.6 … 3.2 mm |
| Underside of the lips | 3.25 mm (0.05 mm above the copper) |
| Parts next to the blank (8 mm band) and the lips | 4.05 mm — 0.85 mm above the copper, below a 1 mm travel height |
| Parts away from the blank, screw heads recessed | 7 mm |

The lips reach 1.2 mm over the blank edge (the G-PCB wizard keeps a 3 mm margin). There are no lips within 10 mm of the stop corner so the bit can reach X0 Y0; a Ø3 mm relief in the corner takes the burr of the blank corner. Every counterbore has at least 3 mm of plastic around it.

## Use

1. Fix the corner stop with its key once and leave it on the bed: its inner corner is X0 Y0.
2. Put the spacer and the blank on the bed and push both into the corner.
3. Slide the X and Y fences against the blank and tighten them.
4. In the G-PCB wizard set X0 Y0 at the stop corner. After the machine was off, the zero is in the same corner again.

The drills and the outline end mill go 0.3 mm below the board — into the spacer, not the aluminium bed.

## Limits of version 1

- The lips are made for a 3.2 mm stack (1.6 mm spacer + 1.6 mm blank). Other thicknesses need a different lip height.
- T-slot dimensions are from a model, not measured.
